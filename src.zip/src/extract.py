"""Extraction components — fetch, reduce, and LLM extraction.

These are the three workhorse functions, ported from the proof-of-concept
notebook into a clean importable module. The pipeline calls them in order:
    fetch_html  ->  html_to_text  ->  extract_menu

Each does ONE job, so when something breaks you know which stage to inspect.
"""

from __future__ import annotations

import os

import requests
from bs4 import BeautifulSoup
from google import genai
from google.genai import types

from .schema import CollegeMenu

# ---------------------------------------------------------------------------
# Model + client setup
# ---------------------------------------------------------------------------
# The model name lives in ONE place. Swap this string to change models; nothing
# else depends on the specific model.
MODEL_NAME = "gemini-2.5-flash"


def _build_client() -> genai.Client:
    """Create the Gemini client from the environment key.

    Done lazily in a function so importing this module never fails just because
    a key is missing — only calling extract_menu requires it.
    """
    api_key = os.environ.get("GEMINI_API_KEY")
    if not api_key:
        raise RuntimeError(
            "GEMINI_API_KEY not set. In PowerShell:\n"
            '    $env:GEMINI_API_KEY = "your-key-here"'
        )
    return genai.Client(api_key=api_key)


# A realistic User-Agent. Some sites serve stripped pages to unknown clients.
_HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36"
    )
}


# ---------------------------------------------------------------------------
# Stage 1 — fetch
# ---------------------------------------------------------------------------
def fetch_html(url: str, timeout: int = 20) -> str:
    """Return raw HTML for a URL. Raises on HTTP error or timeout."""
    resp = requests.get(url, headers=_HEADERS, timeout=timeout)
    resp.raise_for_status()
    return resp.text


# ---------------------------------------------------------------------------
# Stage 2 — reduce
# ---------------------------------------------------------------------------
def html_to_text(html: str) -> str:
    """Strip boilerplate and return readable plain text.

    Remove script/style/nav/footer/header tags, then extract text with newline
    separators so the day/meal structure survives for the model. This cuts token
    cost and improves accuracy by removing noise.
    """
    soup = BeautifulSoup(html, "html.parser")
    for tag in soup(["script", "style", "nav", "footer", "header", "noscript"]):
        tag.decompose()
    text = soup.get_text(separator="\n")
    lines = [ln.strip() for ln in text.splitlines()]
    lines = [ln for ln in lines if ln]
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Stage 3 — extract
# ---------------------------------------------------------------------------
_SYSTEM_INSTRUCTION = """\
You extract dining-hall menus from college webpage text into a strict schema.

Rules:
- Include breakfast, brunch, lunch, and dinner sittings where present. Brunch is
  common at weekends. Ignore opening hours, contact details, and prose.
- Normalise dietary tags to lowercase from this set only:
  vegan, vegetarian, halal, gluten-free.
  Map common codes: (V)/V -> vegetarian, (VG)/VG/Vegan -> vegan, (H)/H -> halal,
  GF -> gluten-free. Strip these codes out of the dish 'name'.
- Clean dish names: remove leading bullets, asterisks, and allergen codes.
- If a course (starter/main/side/dessert) is indicated, set it; otherwise null.
- For week_commencing, give the Monday of the menu week as YYYY-MM-DD if you can
  derive it from the page; otherwise null.
- If you cannot find a menu at all, return the college with an empty days list.
- Never invent dishes. Only report what the text supports.
"""


def extract_menu(college: str, page_text: str) -> CollegeMenu:
    """Turn reduced page text into a validated CollegeMenu.

    Uses Gemini's structured-output mode: response_schema constrains the model to
    emit JSON matching our Pydantic schema, and the SDK parses it back into a
    CollegeMenu object on `.parsed`. temperature=0 makes extraction as
    repeatable as possible.
    """
    client = _build_client()
    response = client.models.generate_content(
        model=MODEL_NAME,
        contents=f"College: {college}\n\nPage text:\n{page_text}",
        config=types.GenerateContentConfig(
            system_instruction=_SYSTEM_INSTRUCTION,
            response_mime_type="application/json",
            response_schema=CollegeMenu,
            temperature=0.0,
        ),
    )
    return response.parsed